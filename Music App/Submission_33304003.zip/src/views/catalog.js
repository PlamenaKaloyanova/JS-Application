import { html } from '../../node_modules/lit-html/lit-html.js';
import { gettAll } from '../data/music.js';


//TODO repace with actual view
const catalogTemplate=(albums)=>html`
     <section id="catalogPage">
      <h1>All Albums</h1>
      ${albums.length == 0 ? html`<p>No Albums in Catalog!</p>` : albums.map(albumCard)}
  </section>`;

   const albumCard=(album)=>html`
       <div class="card-box">
           <img src=${album.imgUrl}>
           <div>
               <div class="text-center">
                   <p class="name">Name: ${album.name}</p>
                   <p class="artist">${album.artist}</p>
                   <p class="genre">${album.genre}</p>
                   <p class="price">${album.price}</p>
                   <p class="date">${album.releaseDate}</p>
               </div>
               <div class="btn-group">
                   <a href="/catalog/${album._id}" id="details">Details</a>
               </div>
           </div>
       </div>`


export async function catalogPage(ctx){
    const albums=await gettAll();
    ctx.render(catalogTemplate(albums));
}