//функция за четене на данните от каталога

import { get,del, post, put } from "./api.js";


export async function getAll(){//за catalog.js;
return get('/data/pets?sortBy=_createdOn%20desc&distinct=name')
}

export async function getById(id){//за details.js
    return get('/data/pets/' + id)
}

export async function deleteById(id){//за details.js
    return del('/data/pets/' + id)
}

export async function createPet(petData){//за Create.js
 return post('/data/pets',petData);
}

export async function editPet(id,petData){//за edit.js
return put('/data/pets/' + id,petData);
}