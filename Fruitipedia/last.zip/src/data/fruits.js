import { del, get, post, put } from "./api.js";

export async function getAllFruits() {
    return get('/data/fruits?sortBy=_createdOn%20desc')
}

export async function getFruitsById(id) {
    return get('/data/fruits/' + id)
}

export async function deleteFruit(id) {
    return del('/data/fruits/' + id)
}

export async function createFruit(fruitData) {
    return post('/data/fruits', fruitData)
}

export async function updateFruit(id, fruitData) {
    return put('/data/fruits/' + id, fruitData)
}