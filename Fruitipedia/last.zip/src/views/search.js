import { html } from '../../node_modules/lit-html/lit-html.js';
import { searchFruit } from '../data/search.js';
import { getUserData } from '../util.js';


//TODO repace with actual view
const searchTemplate = (onSearch,fruits) => html`
<section id="search">
    <div class="form">
        <h2>Search</h2>
        <form class="search-form" @submit=${onSearch}>
            <input type="text" name="search" id="search-input" />
            <button class="button-list">Search</button>
        </form>
    </div>
    <h4>Results:</h4>
    <div class="search-result">
        ${fruits.length == 0 ? html`<p class="no-result">No result.</p>` : fruits.map(searchCard)}
    </div>
</section>`;

const searchCard = (fruit) => html`
    <div class="fruit">
        <img src=${fruit.imageUrl} alt="example1" />
        <h3 class="title">${fruit.name}</h3>
        <p class="description">${fruit.description}</p>
        <a class="details-btn" href="/catalog/${fruit._id}">More Info</a>
    </div>`

export async function searchPage(ctx) {
   
    ctx.render(searchTemplate(false,onSearch));

    async function onSearch() {
        const input = document.getElementById('search-input');
        const query = input.value;

        const fruits = await searchFruit(query)
        ctx.render(searchTemplate(true,onSearch,fruits))
    }
}







