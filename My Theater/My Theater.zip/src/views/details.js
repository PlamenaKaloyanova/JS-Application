import { html } from '../../node_modules/lit-html/lit-html.js';
import { deleteTheaterById, getById } from '../data/theaters.js';
import { getUserData } from '../util.js';


//TODO repace with actual view
const detailsTemplate = (theater, onDelete) => html`
<section id="detailsPage">
    <div id="detailsBox">
        <div class="detailsInfo">
            <h1>Title: ${theater.title}</h1>
            <div>
                <img src=${theater.imageUrl}/>
            </div>
        </div>

        <div class="details">
            <h3>Theater Description</h3>
            <p>${theater.description}</p>
            <h4>Date: ${theater.date}</h4>
            <h4>Author: ${theater.author}</h4>
            <div class="buttons">
            ${theater.canEdit ? html`<a @click=${onDelete} class="btn-delete" href="javascript:void(0)">Delete</a>
                <a class="btn-edit" href="/catalog/${theater._id}/edit">Edit</a>` : null}
              
                <a class="btn-like" href="javascript:void(0)">Like</a>
            </div>
            <p class="likes">Likes: 0</p>
        </div>
    </div>
</section>`;




export async function detailsPage(ctx) {
    const id = ctx.params.id;
    const theater = await getById(id);
    const userData = getUserData();

    if (userData && userData._id == theater._ownerId) {
        theater.canEdit = true;
    }
    ctx.render(detailsTemplate(theater, onDelete));

    async function onDelete() {
        const choice = confirm('Are you sure you want to delete this theater?');

        if (choice) {
            await deleteTheaterById(id);
            ctx.page.redirect('/profile')
        }
    }
}