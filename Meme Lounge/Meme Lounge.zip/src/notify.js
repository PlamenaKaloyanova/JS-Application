const container=document.getElementById('errorBox');
const span=container.querySelector('span');

export function notify(message){
    span.textContent=message;
    container.style.display='block';

    setTimeout(()=>container.style.display='none',3000);
}

//импортираме в login.
//да тестваме-//за нотифай;
//window.notify = notify;
//и навсякъде,където сме използвали(views и api.js) alert ще го заменим с Notify;