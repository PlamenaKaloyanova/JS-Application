import { html } from '../../node_modules/lit-html/lit-html.js';
import { getAllProducts } from '../data/products.js';


//TODO repace with actual view
const catalogTemplate=(products)=>html`
  <h2>Products</h2>
 <section id="dashboard">
     <!-- Display a div with information about every post (if any)-->
    ${products.length == 0 ? html` <h2>No products yet.</h2>` : products.map(productCard)} 
 </section>`;


const productCard=(product)=>html`
  <div class="product">
    <img src=${product.imageUrl} />
    <p class="title">${ product.name}</p>
    <p><strong>Price:</strong><span class="price">${product.price}</span>$</p>
    <a class="details-btn" href="/catalog/${product._id}">Details</a>
  </div>`

export async function catalogPage(ctx){
    const products=await getAllProducts()
//  console.log(products[2]['name'])
    ctx.render(catalogTemplate(products));
}