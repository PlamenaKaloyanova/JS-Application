import { setUserData,clearUserData } from "../util.js";
import { get, post } from "./api.js";

const endpoints={
    login:'/users/login',
    register:'/users/register',
    logout:'/users/logout',
}
//TODO Change user object according to project requirement;

export async function login(email,password){
    const result =await post(endpoints.login,{email,password})
    setUserData(result);
}
export async function register(email,password){
    //на сървъра не му трябва втората парола.
    const result =await post(endpoints.register,{email,password});
    setUserData(result);
}
export async function logout(){
    get(endpoints.logout);
    clearUserData();
}

