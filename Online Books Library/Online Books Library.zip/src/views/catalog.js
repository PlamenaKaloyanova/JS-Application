import { html } from '../../node_modules/lit-html/lit-html.js';
import { getById, gettAll } from '../data/books.js';


//TODO repace with actual view
const catalogTemplate=(books)=>html`
<section id="dashboard-page" class="dashboard">
    <h1>Dashboard</h1>
    <ul class="other-books-list">
   ${books.length == 0 ? html`<p class="no-books">No books in database!</p>` 
   : books.map(bookCard)} 
   </ul>
</section>`;
const bookCard=(book)=>html`
        <li class="otherBooks">
            <h3>${book.title}</h3>
            <p>Type: ${book.type}</p>
            <p class="img"><img src=${book.imageUrl}></p>
            <a class="button" href="/catalog/${book._id}">Details</a>
        </li>
    `      


export async  function catalogPage(ctx){
  const books=await gettAll();
  ctx.render(catalogTemplate(books));
}